#!/usr/bin/env python3
"""Agent for secret_number environment."""

import sys
from pathlib import Path

from dotenv import load_dotenv
from run_step import print_final_results, run_step
from states import SecretNumberState, dump, init_fs_tracking, restore
from tools import get_tools

from agent_interp_envs.checkpoint import provider_kwargs, step_dir
from agent_interp_envs.config import load_config
from agent_interp_envs.print_helpers import print_step_header
from agent_interp_envs.providers import create_provider

load_dotenv()


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    """Main agent loop using native tool calling.

    Loads configuration, sets up the provider and secret_number state, then runs the
    agent loop until completion (answer submitted) or max steps reached. Supports
    checkpoint resumption from /opt/checkpoint.
    """
    config_path = sys.argv[1] if len(sys.argv) > 1 else "/opt/config.yaml"
    config = load_config(config_path)

    if Path("/opt/checkpoint").exists():
        state, provider = restore(config, Path("/opt/checkpoint"))
        # Starting from next step
        state.step += 1
    else:
        task_config = config.get("task", {})
        max_guesses = task_config.get("max_guesses", 20)

        # Secret number starts as 0 - will be populated when setup.sh runs
        # and creates /secrets/secret_number.txt
        state = SecretNumberState(
            secret_number=0,
            max_guesses=max_guesses,
            guesses_remaining=max_guesses,
        )
        init_fs_tracking()

        agent_config = config.get("agent", {})
        system_prompt = config.get("prompts", {}).get("system_prompt", "")
        user_prompt = config.get("prompts", {}).get("user_prompt", "")

        provider = create_provider(
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            tools=get_tools(config),
            **provider_kwargs(config),   # every agent.* knob, as on resume
        )

    # Always just print history (handles fresh start & resume identically)
    provider.print_history()

    # Main loop
    max_steps = config.get("agent", {}).get("max_steps", 20)
    submitted = False
    while state.step < max_steps:
        print_step_header(state.step)

        should_quit = run_step(provider, state, config) or getattr(provider, "end_task_called", False)  # end_task_required: the agent called end_task (gigi/3-forensics)
        dump(state, provider, step_dir(state.step))
        state.step += 1

        if should_quit:
            submitted = True
            break

    if not submitted:
        print_final_results(state, completed=False)


if __name__ == "__main__":
    main()
