#!/usr/bin/env python3
"""Agent for ai_rd environment."""

import sys
from pathlib import Path

from dotenv import load_dotenv
from run_step import print_final_results, run_step
from states import AIRDState, dump, init_fs_tracking, restore
from tools import EXECUTE_COMMAND_TOOL

from agent_interp_envs.checkpoint import provider_kwargs, step_dir
from agent_interp_envs.config import load_config
from agent_interp_envs.print_helpers import print_step_header
from agent_interp_envs.providers import create_provider

load_dotenv()


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    """Main agent loop.

    Loads configuration, sets up the provider and state, then runs the
    agent loop until completion (no tool call response) or max steps reached.
    Supports checkpoint resumption from /opt/checkpoint.
    """
    config_path = sys.argv[1] if len(sys.argv) > 1 else "/opt/config.yaml"
    config = load_config(config_path)

    if Path("/opt/checkpoint").exists():
        state, provider = restore(config, Path("/opt/checkpoint"))
        state.step += 1
    else:
        state = AIRDState()
        init_fs_tracking()

        agent_config = config.get("agent", {})
        system_prompt = config.get("prompts", {}).get("system_prompt", "")
        user_prompt = config.get("prompts", {}).get("user_prompt", "")

        provider = create_provider(
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            tools=[EXECUTE_COMMAND_TOOL],
            **provider_kwargs(config),
        )

    provider.print_history()

    # Main loop
    max_steps = config.get("agent", {}).get("max_steps", 30)
    completed = False
    while state.step < max_steps:
        print_step_header(state.step)

        should_quit = run_step(provider, state, config) or getattr(provider, "end_task_called", False)  # end_task_required: the agent called end_task (gigi/3-forensics)
        dump(state, provider, step_dir(state.step))
        state.step += 1

        if should_quit:
            completed = True
            break

    if not completed:
        print_final_results(state, completed=False)
        # Dump final state with populated metrics (print_final_results fills them in)
        dump(state, provider, step_dir(state.step - 1))


if __name__ == "__main__":
    main()
