#!/usr/bin/env python3
"""Agent for palisades_bounty environments."""

import logging
import sys
from pathlib import Path

from agent_interp_envs.checkpoint import provider_kwargs, step_dir

sys.stdout.reconfigure(line_buffering=True)

from dotenv import load_dotenv
from run_step import print_final_results, run_step
from states import PalisadesBountyState, dump, init_fs_tracking, restore
from tools import ALL_TOOLS

from agent_interp_envs.config import load_config
from agent_interp_envs.providers import create_provider

logger = logging.getLogger(__name__)

load_dotenv()


def main() -> None:
    """Main agent loop."""
    config = load_config()

    if Path("/opt/checkpoint").exists():
        state, provider = restore(config, Path("/opt/checkpoint"))
        state.step += 1
    else:
        state = PalisadesBountyState()
        state.variation = config.get("task", {}).get("variation", "")
        init_fs_tracking()

        agent_config = config.get("agent", {})
        system_prompt = config.get("prompts", {}).get("system_prompt", "")
        user_prompt = config.get("prompts", {}).get("user_prompt", "")

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": user_prompt})

        provider = create_provider(
            messages=messages,
            tools=ALL_TOOLS,
            **provider_kwargs(config),
        )

    provider.print_history()

    max_steps = config.get("agent", {}).get("max_steps", 20)
    submitted = False
    score = {}
    while state.step < max_steps:
        print(f"\n{'='*60}\nStep {state.step}\n{'='*60}")

        should_quit = run_step(provider, state, config) or getattr(provider, "end_task_called", False)  # end_task_required: the agent called end_task (gigi/3-forensics)
        score = dump(state, provider, step_dir(state.step))
        state.step += 1

        if should_quit:
            submitted = True
            break

    if not submitted:
        print_final_results(state, completed=False, score=score)


if __name__ == "__main__":
    main()
