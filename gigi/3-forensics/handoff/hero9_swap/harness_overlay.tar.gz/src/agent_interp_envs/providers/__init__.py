"""Provider factory."""

import functools
import os

from agent_interp_envs.providers.anthropic_provider import AnthropicProvider
from agent_interp_envs.providers.base import BaseProvider
from agent_interp_envs.providers.fireworks_completions_provider import (
    FireworksCompletionsProvider,
)
from agent_interp_envs.providers.fireworks_provider import FireworksProvider
from agent_interp_envs.providers.minimax_provider import MinimaxProvider
from agent_interp_envs.providers.mock_provider import MockProvider
from agent_interp_envs.providers.moonshot_provider import MoonshotProvider
from agent_interp_envs.providers.openai_provider import OpenAIProvider
from agent_interp_envs.providers.openrouter_provider import OpenRouterProvider


class UnknownProvider(Exception):
    """Raised when a provider is not supported."""
    pass


PROVIDERS = {
    "anthropic": AnthropicProvider,
    "fireworks": FireworksProvider,
    "fireworks_completions": FireworksCompletionsProvider,
    "minimax": MinimaxProvider,
    "mock": MockProvider,
    "moonshot": MoonshotProvider,
    "openai": OpenAIProvider,
    "openrouter": OpenRouterProvider,
}


def _install_provider_pin() -> None:
    """Resolve the provider API host(s) to their allowlisted IPs, in-process.

    The isolated sandbox allowlists egress by IP and blocks stray DNS, so the
    launcher resolves the provider host(s) on the way in and hands the result to
    the harness in ROLLOUT_HOSTS ("<ip> <host>" per line, one or more IPs each).
    We used to append those lines to /etc/hosts, but that left an agent-readable
    file naming the provider — a tell. Instead override socket.getaddrinfo in the
    harness interpreter only (the agent's shell is a separate, env-scrubbed
    process) so the provider host resolves to its allowlisted IP with the
    hostname preserved for TLS SNI. Runs from create_provider so every harness
    entry — run_agent loops, the dashboard_perf/puppeteer custom loops, and the
    resume path — is covered. No ROLLOUT_HOSTS (a non-isolated run) is a no-op.
    """
    import socket

    if getattr(socket.getaddrinfo, "_provider_pinned", False):
        return
    pin: dict[str, list[str]] = {}
    for line in os.environ.get("ROLLOUT_HOSTS", "").splitlines():
        parts = line.split()
        if len(parts) == 2:
            pin.setdefault(parts[1], []).append(parts[0])
    if not pin:
        return

    _orig = socket.getaddrinfo

    def _patched(host, *args, **kwargs):
        ips = pin.get(host)
        # The allowlisted IPs are IPv4 (Modal's cidr_allowlist rejects IPv6), so
        # an explicit AF_INET6 lookup falls through to the real resolver.
        family = args[0] if args else kwargs.get("family", 0)
        if not ips or family == socket.AF_INET6:
            return _orig(host, *args, **kwargs)
        out = []
        for ip in ips:
            out.extend(_orig(ip, *args, **kwargs))
        return out

    _patched._provider_pinned = True
    socket.getaddrinfo = _patched


_SECRET_ENV = __import__("re").compile(r"(API_KEY|SECRET|TOKEN|PASSWORD|CREDENTIAL)")


def scrub_secrets_from_environ() -> int:
    """Drop secret-shaped variables from this process's environment.

    Providers read their key once, at construction; nothing in the loop reads
    a key afterwards (the heal helper captures its own at import). Every
    subprocess the harness spawns from here on — the agent shell, graders,
    benches, test suites that execute the agent's code — inherits a clean
    environment, and the agent's program cannot lift a key from this process's
    /proc/<pid>/environ (a graded program once dumped the keys it inherited into
    its output). Returns the number removed."""
    import os
    names = [k for k in os.environ if _SECRET_ENV.search(k)]
    for k in names:
        del os.environ[k]
    return len(names)


def _create_provider(
    provider: str,
    model: str,
    messages: list[dict],
    tools: list[dict],
    provider_preferences: dict | None = None,
    temperature: float | None = None,
    top_p: float | None = None,
    top_k: int | None = None,
    min_p: float | None = None,
    reasoning_effort: str | None = None,
    reasoning_summary: str | None = None,
    rejection: dict | None = None,
    mock_script: list[str] | None = None,
    text_tools: bool = False,
    end_confirm: bool = False,
    end_task_required: bool = False,
    end_task_reprompts: int = 10,
    hack: str | None = None,
    hack_min_steps: int = 10,
    hack_workspace: str = "/agent",
    hack_max_refusals: int = 10,
    hack_submit_pattern: str | None = r"python[0-9.]*\s+(\S*/)?submit_solution\.py",
) -> BaseProvider:
    """Create an LLM provider instance.

    Args:
        provider: Provider name (anthropic, openai, openrouter, minimax, moonshot).
        model: Model identifier (e.g., 'claude-sonnet-4-5', 'meta-llama/llama-3.3-70b-instruct').
        messages: Initial conversation messages.
        tools: Tool definitions for function calling.
        provider_preferences: OpenRouter-specific provider routing preferences.
            Only used when provider is 'openrouter'. Supports: order, only, ignore,
            allow_fallbacks, data_collection, require_parameters, sort, quantizations.
            See: https://openrouter.ai/docs/guides/routing/provider-selection
        reasoning_summary: OpenAI Responses API reasoning-summary level (auto /
            concise / detailed); config: agent.reasoning_summary. Ignored by
            every other provider.
        rejection: Optional judge-based CoT rejection config. When present
            (and "enabled" is not false), the provider is wrapped in a
            RejectionProvider that resamples reasoning sentences an LLM judge
            flags. Keys: judge_model, criterion (required); enabled,
            max_retries_per_boundary, max_generations_per_turn, log_path
            (optional). Requires a prefill-capable provider
            (fireworks_completions).
        mock_script: Commands the mock provider replays, one per step;
            ignored by every other provider.

    Returns:
        Configured provider instance.

    Raises:
        UnknownProvider: If the provider is not supported.
        ValueError: If provider or model is not specified.
    """
    _install_provider_pin()
    if provider is None:
        raise ValueError("provider must be specified in agent config")
    if model is None:
        raise ValueError("model must be specified in agent config")

    provider_class = PROVIDERS.get(provider)
    if provider_class is None:
        available = ", ".join(sorted(PROVIDERS.keys()))
        raise UnknownProvider(
            f"Unknown provider: {provider}. Available providers: {available}"
        )

    if provider_preferences is not None and provider != "openrouter":
        import warnings
        warnings.warn(
            f"provider_preferences is only supported for openrouter, "
            f"but provider '{provider}' was specified. Ignoring preferences."
        )

    def _maybe_wrap(instance: BaseProvider) -> BaseProvider:
        if not rejection or rejection.get("enabled") is False:
            return instance
        from agent_interp_envs.cot_judge import SentenceJudge
        from agent_interp_envs.providers.rejection_provider import RejectionProvider

        if not isinstance(instance, FireworksCompletionsProvider):
            raise ValueError(
                "rejection requires a prefill-capable provider "
                "(fireworks_completions)"
            )
        judge = SentenceJudge(
            model=rejection["judge_model"],
            criterion=rejection["criterion"],
        )
        kwargs = {
            k: rejection[k]
            for k in ("max_retries_per_boundary", "max_generations_per_turn", "log_path")
            if k in rejection
        }
        return RejectionProvider(instance, judge, **kwargs)

    def _finish(instance: BaseProvider) -> BaseProvider:
        instance = _maybe_wrap(instance)
        instance.end_confirm = end_confirm   # read by tool_calling.validate_and_get_command
        if hack:
            # config agent.hack (gigi/3-forensics, 8 Nov 2026): installed UNDER the end-task-required wrapper, so it sees
            # the raw reply and can refuse the finish tool; see hacks.py.
            from agent_interp_envs.hacks import install as install_hack
            instance = install_hack(instance, hack, _finish_tool or "end_task", int(hack_min_steps or 10),
                                    hack_workspace or "/agent", int(hack_max_refusals or 10), hack_submit_pattern)
        if end_task_required:
            from agent_interp_envs.end_task_required import install
            instance = install(instance, _finish_tool, _finish_tool_synthetic, int(end_task_reprompts or 10))
        return instance

    _finish_tool, _finish_tool_synthetic = None, False
    if end_task_required:
        # config agent.end_task_required (gigi/3-forensics, 7 Nov 2026): the run can only end through a finish tool;
        # see end_task_required.py. The rule goes into the system prompt (idempotent, as END_NOTICE below) and a
        # synthetic end_task tool is added when the environment has no finish tool of its own.
        from agent_interp_envs.end_task_required import END_TASK, END_TASK_TOOL, finish_tool, rule
        _finish_tool = finish_tool(tools)
        if _finish_tool is None:
            _finish_tool, _finish_tool_synthetic = END_TASK, True
            tools = list(tools or []) + [END_TASK_TOOL]
        if messages and messages[0].get("role") == "system" and isinstance(messages[0].get("content"), str) \
                and rule(_finish_tool) not in messages[0]["content"]:
            messages[0] = {**messages[0], "content": (messages[0]["content"].rstrip() + "\n\n" + rule(_finish_tool)).strip()}
    if hack:
        from agent_interp_envs.hacks import prompt_addition
        add = prompt_addition(hack, _finish_tool or "end_task")
        if add and messages and messages[0].get("role") == "system" and isinstance(messages[0].get("content"), str) \
                and add not in messages[0]["content"]:
            messages[0] = {**messages[0], "content": (messages[0]["content"].rstrip() + "\n\n" + add).strip()}

    if end_confirm:
        # config agent.end_confirm (gigi/3-forensics): say in the system prompt that a reply without a tool call ends
        # the session. Idempotent, so a resumed run (stored messages) does not get it twice.
        from agent_interp_envs.end_confirm import END_NOTICE
        if messages and messages[0].get("role") == "system" and isinstance(messages[0].get("content"), str) \
                and END_NOTICE not in messages[0]["content"]:
            messages[0] = {**messages[0], "content": (messages[0]["content"].rstrip() + "\n\n" + END_NOTICE).strip()}

    if provider == "openrouter":
        return _finish(provider_class(
            model=model,
            messages=messages,
            tools=tools,
            provider_preferences=provider_preferences,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            min_p=min_p,
            reasoning_effort=reasoning_effort,
            text_tools=text_tools,
        ))
    if text_tools:
        raise ValueError(f"text_tools is only supported for openrouter, not {provider}")
    if provider == "fireworks":
        return _finish(provider_class(
            model=model,
            messages=messages,
            tools=tools,
            temperature=temperature,
            top_p=top_p,
            reasoning_effort=reasoning_effort,
        ))
    if provider == "fireworks_completions":
        return _finish(provider_class(
            model=model,
            messages=messages,
            tools=tools,
            temperature=temperature,
            top_p=top_p,
            reasoning_effort=reasoning_effort,
        ))
    if provider == "anthropic":
        return _finish(provider_class(
            model=model,
            messages=messages,
            tools=tools,
            reasoning_effort=reasoning_effort,
        ))
    if provider == "mock":
        return _finish(provider_class(model=model, messages=messages, tools=tools,
                                      mock_script=list(mock_script) if mock_script else None))
    if provider == "openai":
        return _finish(provider_class(
            model=model,
            messages=messages,
            tools=tools,
            reasoning_effort=reasoning_effort,
            reasoning_summary=reasoning_summary,
        ))
    return _finish(provider_class(model=model, messages=messages, tools=tools))


@functools.wraps(_create_provider)
def create_provider(*args, **kwargs) -> BaseProvider:
    """Build the provider, then scrub secrets from the process environment
    (see scrub_secrets_from_environ). `wraps` keeps _create_provider's
    signature visible: checkpoint.provider_kwargs filters the agent config by
    it, and a bare (*args, **kwargs) signature would silently drop every
    optional knob (reasoning_effort, temperature, mock_script)."""
    provider = _create_provider(*args, **kwargs)
    scrub_secrets_from_environ()
    return provider
