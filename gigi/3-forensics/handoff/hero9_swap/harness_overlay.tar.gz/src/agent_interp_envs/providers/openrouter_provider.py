"""Interleaved thinking via OpenRouter API

OpenRouter interleaved thinking supported models:
- OpenAI: o1 series, o3 series, GPT-5 series
- Anthropic: Claude 4+ series
- All Gemini reasoning models
- All xAI reasoning models
- MiniMax M2
- Kimi K2 Thinking
- INTELLECT-3
"""

import ast
import json
import re
import uuid

from dotenv import load_dotenv
from openai import APIConnectionError, APITimeoutError, OpenAI, RateLimitError
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from agent_interp_envs.print_helpers import print_section, print_step_header
from agent_interp_envs.providers._keys import require_api_key
from agent_interp_envs.providers.base import BaseProvider
from agent_interp_envs.types import LLMResponse, ToolCall, ToolResult

load_dotenv()


class OpenRouterEmptyResponseError(Exception):
    """OpenRouter returned HTTP 200 with an error body and no choices."""


# gigi/3-forensics: gemma-3 has no tool-call tokens. Through OpenRouter (DeepInfra) it writes its
# call as text in its own format, e.g. ```tool_code\n[execute_command(command='ls')]\n```, which
# the harness reads as a prose reply (ending the run, or nudging it into a loop of apologies).
# When a reply has no structured tool call, the first call in such a block that names one of the
# offered tools becomes a structured call (a block counts only if it calls a tool by name). The
# text stays in the message unchanged. An empty reply (no text, no call) is a provider glitch, not
# a choice: it is retried like a missing one instead of being read as the agent's final reply.
_TOOL_CODE = re.compile(r"```(?:tool_code|python|py|json)?[ \t]*\n(.*?)```", re.S)   # gemma also labels it python, json, or nothing


def _tool_call_from_tool_code(content: str, tools: list[dict]) -> dict | None:
    params = {t["function"]["name"]: list((t["function"].get("parameters") or {}).get("properties") or {})
              for t in tools if t.get("type") == "function"}
    types = {t["function"]["name"]: {k: (v or {}).get("type") for k, v in
                                     ((t["function"].get("parameters") or {}).get("properties") or {}).items()}
             for t in tools if t.get("type") == "function"}
    # fenced blocks first, then any line that is nothing but a call (gemma sometimes ends a plain
    # reply with a bare `[execute_command(command="...")]` line); prose never parses as code
    candidates = _TOOL_CODE.findall(content or "") + [ln for ln in (content or "").splitlines()
                                                     if ln.strip()[:1] in "[(" or ln.strip().split("(")[0].split(".")[-1] in params]
    while candidates:
        block = candidates.pop(0)
        try:
            tree = ast.parse(block.strip())
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            # gemma sometimes quotes the call: ```json ["execute_command(command='...')"]```
            if isinstance(node, ast.Constant) and isinstance(node.value, str) and "(" in node.value:
                candidates.append(node.value)
            if not isinstance(node, ast.Call):
                continue
            name = node.func.attr if isinstance(node.func, ast.Attribute) else getattr(node.func, "id", None)
            if name not in params:
                continue
            try:
                args = {kw.arg: ast.literal_eval(kw.value) for kw in node.keywords if kw.arg}
                positional = [ast.literal_eval(v) for v in node.args]
            except (ValueError, SyntaxError):
                continue
            # gemma also writes `execute_command({"command": "ls"})`: one dict of the tool's own parameter
            # names, passed positionally, is the arguments themselves (not the first parameter's value)
            if (len(positional) == 1 and not args and isinstance(positional[0], dict) and positional[0]
                    and set(positional[0]) <= set(params[name])):
                args = dict(positional[0])
            else:
                args.update(dict(zip(params[name], positional)))
            # a string parameter given a dict or list gets it as JSON text, as a schema-checked API would
            args = {k: json.dumps(v) if types[name].get(k) == "string" and isinstance(v, (dict, list)) else v
                    for k, v in args.items()}
            return {"id": f"call_{uuid.uuid4().hex[:24]}", "type": "function",
                    "function": {"name": name, "arguments": json.dumps(args)}}
    return None


# gigi/3-forensics (25 Oct 2026): a call gemma writes but that does not parse (quotes inside quotes, a bracket
# never closed) or that names a tool we don't offer (`bash(...)`) used to read as "no call", which several
# environments take as the agent's final answer, so the run ended. A native model's malformed or unknown call
# gets an error back instead ("invalid arguments" / "unknown function") and the run goes on. So, in text mode,
# such a call is passed on as a call whose arguments are the raw text (not JSON): the environment answers it
# exactly as it answers a native model's malformed call. A block counts only if it starts with a call: an
# offered tool's name in a tool_code/python/bare block, or any name in a tool_code block. Checked on the saved
# runs (25 Oct): 50 of the 52 replies our parser had ended become such calls (the other 2 type a fake
# ```tool_output``` and no call); none of gemma's 1,013 final answers does.
_LABELLED_BLOCK = re.compile(r"```(tool_code|python|py)?[ \t]*\n(.*?)(?:```|\Z)", re.S)
_CALL_START = re.compile(r"\s*\[?\s*([A-Za-z_][\w.]*)\s*\(")


def _unparsed_tool_call(content: str, tools: list[dict]) -> dict | None:
    names = {t["function"]["name"] for t in tools if t.get("type") == "function"}
    for label, block in _LABELLED_BLOCK.findall(content or ""):
        # a tool_code block is a call by gemma's own convention, with or without brackets (`bash "ls"`)
        m = _CALL_START.match(block) or (label == "tool_code" and re.match(r"\s*\[?\s*([A-Za-z_][\w.]*)", block))
        if not m:
            continue
        name = m.group(1).split(".")[-1]
        if name in names or label == "tool_code":
            return {"id": f"call_unparsed_{uuid.uuid4().hex[:16]}", "type": "function",
                    "function": {"name": name, "arguments": block.strip()}}
    return None


# Text-mode tool calling (agent.text_tools: true), for models with no tool-call tokens (gemma-3): the
# request carries no `tools`; the system prompt carries Google's Gemma 3 function-calling instruction
# (verbatim, from philschmid.de/gemma-function-calling, the reference Google points to) and the tools as
# Python stubs; every earlier call in the history (this model's or another's, e.g. Qwen's in a swap) is
# shown as a ```tool_code``` block and every tool result as a ```tool_output``` block in a user turn.
# The reply is parsed back into a structured call (_tool_call_from_tool_code), so the stored history,
# checkpoints and transcripts keep the standard format. Nothing is dropped by a provider-side parser.
TEXT_TOOLS_INSTRUCTION = (
    "At each turn, if you decide to invoke any of the function(s), it should be wrapped with ```tool_code```. "
    "The python methods described below are imported and available, you can only use defined methods. "
    "The generated code should be readable and efficient. The response to a method will be wrapped in "
    "```tool_output``` use it to call more tools or generate a helpful, friendly response. When using a "
    "```tool_call``` think step by step why and how it should be used.")
_PY_TYPES = {"string": "str", "integer": "int", "number": "float", "boolean": "bool", "array": "list", "object": "dict"}


def _python_stub(tool: dict) -> str:
    """One tool as a Python signature with its description and arguments as the docstring."""
    fn = tool["function"]; params = fn.get("parameters") or {}
    props = params.get("properties") or {}; required = set(params.get("required") or [])
    sig = ", ".join(f"{k}: {_PY_TYPES.get(v.get('type'), 'str')}" + ("" if k in required else " = None")
                    for k, v in props.items())
    doc = [fn.get("description", "").strip()]
    if props:
        doc += ["", "Args:"] + [f"  {k}: {(v.get('description') or '').strip()}" for k, v in props.items()]
    body = "\n".join("    " + ln if ln else "" for ln in doc)
    return f'def {fn["name"]}({sig}) -> str:\n    """\n{body}\n    """'


def _call_text(name: str, arguments: str) -> str:
    try:
        args = json.loads(arguments) if arguments else {}
        args = json.loads(args) if isinstance(args, str) else args
    except (ValueError, TypeError):
        return f"{name}()"
    return f"{name}(" + ", ".join(f"{k}={v!r}" for k, v in (args or {}).items()) + ")"


def _text_tools_messages(messages: list[dict], tools: list[dict]) -> list[dict]:
    """The history as a model without tool-call tokens sees it (see TEXT_TOOLS_INSTRUCTION)."""
    preamble = (TEXT_TOOLS_INSTRUCTION + "\n\nThe following Python methods are available:\n\n```python\n"
                + "\n\n".join(_python_stub(t) for t in tools if t.get("type") == "function") + "\n```")
    out: list[dict] = []
    for m in messages:
        role, content = m["role"], m.get("content")
        content = content if isinstance(content, str) else ("" if content is None else json.dumps(content))
        if role == "system":
            out.append({"role": "system", "content": f"{content}\n\n{preamble}"})
        elif role == "assistant":
            text = content
            # a call already written as text (this model's own turn, readable or not) is shown as written
            unparsed = all(tc.get("id", "").startswith("call_unparsed_") for tc in m.get("tool_calls") or [{}])
            if m.get("tool_calls") and not unparsed and not _tool_call_from_tool_code(text, tools):
                blocks = [f"```tool_code\n{_call_text(tc['function']['name'], tc['function'].get('arguments'))}\n```"
                          for tc in m["tool_calls"]]
                text = "\n".join([text.strip()] + blocks if text.strip() else blocks)
            out.append({"role": "assistant", "content": text})
        else:   # tool results and mid-run user messages: one user turn, so turns keep alternating
            text = f"```tool_output\n{content}\n```" if role == "tool" else content
            if out and out[-1]["role"] == "user":
                out[-1]["content"] += "\n\n" + text
            else:
                out.append({"role": "user", "content": text})
    if not any(m["role"] == "system" for m in out):
        first = next((m for m in out if m["role"] == "user"), None)
        if first is not None:
            first["content"] = f"{preamble}\n\n{first['content']}"
    return out


class OpenRouterProvider(BaseProvider):
    """Provider for OpenRouter models using OpenAI-compatible chat completions API.

    Supports reasoning via extra_body parameter and handles tool calls
    following the standard OpenAI format.
    """

    def __init__(
        self,
        model: str,
        messages: list[dict],
        tools: list[dict],
        provider_preferences: dict | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        min_p: float | None = None,
        reasoning_effort: str | None = None,
        text_tools: bool = False,
    ) -> None:
        """Initialize the OpenRouter provider.

        Args:
            model: Model identifier (e.g., 'anthropic/claude-sonnet-4').
            messages: Initial conversation messages.
            tools: Tool definitions for function calling.
            provider_preferences: OpenRouter provider routing preferences.
                Supports: order, only, ignore, allow_fallbacks, data_collection,
                require_parameters, sort, quantizations, etc.
                See: https://openrouter.ai/docs/guides/routing/provider-selection
            temperature: Optional sampling temperature. If None, the field is omitted
                from the request body and the upstream provider's default applies.
            top_p: Optional nucleus sampling parameter. Same omission semantics as temperature.
        """
        # OpenRouter is the right backend for models Fireworks doesn't host —
        # but never as a hop TO Fireworks: that path's rate limits are terrible
        # and it burns whole batches of rollouts. Pin such models to the fireworks provider
        # (provider: fireworks, FIREWORKS_API_KEY) instead.
        routed = {str(v) for v in (provider_preferences or {}).get("order", [])}
        routed |= {str(v) for v in (provider_preferences or {}).get("only", [])}
        if any("fireworks" in r.lower() for r in routed):
            raise ValueError(
                "Refusing to route to Fireworks via OpenRouter (terrible rate "
                "limits). Use the fireworks provider directly."
            )
        api_key = require_api_key("OPENROUTER_API_KEY", "openrouter")
        self.client = OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=api_key,
            # SDK retries stack multiplicatively under the tenacity retry on
            # invoke(); disabled so rate limiting surfaces there instead of
            # sleeping silently.
            max_retries=0,
            default_headers={
                "x-anthropic-beta": "interleaved-thinking-2025-05-14",
            },
        )
        self.model = model
        self.messages = messages
        # reasoning_effort "none": no reasoning field at all, for models without a
        # reasoning mode (gigi/3-forensics: Qwen3-Next-80B Instruct, gemma-3-27b)
        # reasoning_effort "disabled" (opt-in, gigi/3-forensics hero swap, 4 Nov 2026): thinking switched OFF for a
        # model whose reasoning is on by default (Qwen3.6 27B: OpenRouter reports reasoning.default_enabled true),
        # via OpenRouter's documented off switch {"reasoning": {"effort": "none"}}. Not "off": YAML/OmegaConf read
        # a bare `off` as the boolean False, which would fall through to "xhigh". Every other value as before.
        if reasoning_effort == "disabled":
            extra_body = {"reasoning": {"effort": "none"}}
        else:
            extra_body = {} if reasoning_effort == "none" else {"reasoning": {"effort": reasoning_effort or "xhigh"}}
        if provider_preferences:
            extra_body["provider"] = provider_preferences
        # Tool-less runs (e.g. a no-tools eval variant) must omit both keys:
        # upstream APIs reject an empty tools array and reject
        # parallel_tool_calls without tools.
        self.kwargs = {"extra_body": extra_body}
        self.text_tools = bool(text_tools)
        self.tool_defs = list(tools or [])
        if tools and not self.text_tools:
            self.kwargs["tools"] = tools
            self.kwargs["parallel_tool_calls"] = False
        if temperature is not None:
            self.kwargs["temperature"] = temperature
        if top_p is not None:
            self.kwargs["top_p"] = top_p
        # not OpenAI-SDK fields, so they go in the request body directly
        if top_k is not None:
            extra_body["top_k"] = top_k
        if min_p is not None:
            extra_body["min_p"] = min_p
        

    @retry(
        # A 429 produced no reply, so waiting it out resamples nothing: up to 14 attempts (~20 min) while
        # DeepInfra's shared pool is overloaded. Anything else (an empty reply is a dropped reply) stops at 3.
        stop=lambda rs: rs.attempt_number >= (
            14 if isinstance(rs.outcome.exception(), RateLimitError) else 3),
        wait=wait_exponential(multiplier=2, min=1, max=120),
        retry=retry_if_exception_type(
            (RateLimitError, APITimeoutError, APIConnectionError, OpenRouterEmptyResponseError, json.JSONDecodeError)
        ),
        # a retry resamples the reply, so log each one: silent resampling would hide replies the provider dropped
        before_sleep=lambda rs: print(
            f"[provider retry] attempt {rs.attempt_number} failed: {type(rs.outcome.exception()).__name__}", flush=True),
    )
    def invoke(self) -> LLMResponse:
        """Make an API call to OpenRouter using internal message history.

        Returns:
            LLMResponse with parsed content, reasoning, and tool calls.
        """
        response = self.client.chat.completions.create(
            model=self.model,
            messages=_text_tools_messages(self.messages, self.tool_defs) if self.text_tools else self.messages,
            **self.kwargs,
        )

        if not response.choices:
            error = getattr(response, "error", None) or (response.model_extra or {}).get("error")
            raise OpenRouterEmptyResponseError(f"OpenRouter returned no choices: {error}")

        message = response.choices[0].message.model_dump()
        if not message.get("tool_calls") and not (message.get("content") or "").strip():
            raise OpenRouterEmptyResponseError("OpenRouter returned an empty reply (no text, no tool call)")
        if not message.get("tool_calls") and (self.kwargs.get("tools") or self.text_tools):
            parsed = _tool_call_from_tool_code(message.get("content") or "", self.tool_defs)
            if not parsed and self.text_tools:
                parsed = _unparsed_tool_call(message.get("content") or "", self.tool_defs)
            if parsed:
                message["tool_calls"] = [parsed]

        # Required for moonshot models
        if message.get("reasoning") and not message.get("reasoning_content"):
            message["reasoning_content"] = message["reasoning"]

        self.messages.append(message)

        tool_calls = [
            ToolCall(
                id=tool_call['id'],
                name=tool_call['function']['name'],
                arguments=tool_call['function']['arguments'],
            )
            for tool_call in message.get("tool_calls") or []
        ]

        return LLMResponse(
            reasoning=message.get("reasoning"),
            response=message.get("content"),
            tool_calls=tool_calls,
        )

    def add_tool_result(self, tool_result: ToolResult) -> None:
        """Add a tool result to message history."""
        content = tool_result.content
        # OpenRouter's Gemini translation replaces a string tool result with
        # any JSON object it can parse out of the string's brace-span, so
        # "{}" anywhere in the output blanks the whole result. Pre-wrapping
        # makes the entire string that object; the text survives losslessly
        # as {"output": ...}.
        if "gemini" in self.model:
            content = json.dumps({"output": content})
        self.messages.append(
            {
                "role": "tool",
                "tool_call_id": tool_result.id,
                "content": content,
            }
        )

    def print_history(self) -> None:
        """Print full message history in run_step format."""
        step = 0
        i = 0
        
        while i < len(self.messages):
            msg = self.messages[i]
            
            if msg["role"] == "system":
                print()
                print_section("SYSTEM PROMPT", msg["content"])
                
            elif msg["role"] == "user" and i == 1:
                # First user message is the task prompt
                print_section("USER_PROMPT", msg["content"])
                
            elif msg["role"] == "assistant":
                print_step_header(step)
                

                if msg.get("reasoning"):
                    print()
                    print_section("REASONING", msg["reasoning"])
                
                if msg.get("content"):
                    print_section("RESPONSE", msg["content"])
                
                if msg.get("tool_calls"):
                    for tc in msg["tool_calls"]:
                        tool_calls_content = f"Function: {tc['function']['name']}\nArguments: {tc['function']['arguments']}"
                        print_section("TOOL CALL", tool_calls_content)
                
            elif msg["role"] == "tool":
                print_section("TOOL RESULT", msg["content"])
                step += 1
                
            elif msg["role"] == "user":
                # Mid-conversation user messages (e.g., retry prompts)
                print_section("USER MESSAGE", msg["content"])
                step += 1
                
            i += 1

    def revert_last_turn(self):
        """Remove the last assistant turn from history."""
        self.messages = self.messages[:-1]
